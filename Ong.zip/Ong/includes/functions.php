<?php
session_start();

$api_url = "http://localhost/Ong"; // Ajuste conforme sua configuração

function api_request($endpoint, $method = 'GET', $data = null, $multipart = false) {
    global $api_url;
    
    $url = $api_url . '/' . ltrim($endpoint, '/');
    $ch = curl_init();
    
    $headers = [];
    
    if(isset($_SESSION['token'])) {
        $headers[] = 'Authorization: Bearer ' . $_SESSION['token'];
    }
    
    if($method == 'POST' && !$multipart) {
        $headers[] = 'Content-Type: application/json';
        $data = json_encode($data);
    } elseif($method == 'PUT' && !$multipart) {
        $headers[] = 'Content-Type: application/json';
        $data = json_encode($data);
    }
    
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    if($data) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }
    
    if(!empty($headers)) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return [
        'status' => $http_code,
        'data' => json_decode($response, true)
    ];
}

function is_logged_in() {
    if(!isset($_SESSION['user_id']) || !isset($_SESSION['token'])) {
        return false;
    }
    
    // Verifica se o token ainda é válido (opcional)
    return true;
}

function redirect_if_not_logged_in() {
    if(!is_logged_in()) {
        header('Location: login.php');
        exit();
    }
}

function format_cnpj($cnpj) {
    $cnpj = preg_replace('/[^0-9]/', '', $cnpj);
    if(strlen($cnpj) == 14) {
        return preg_replace('/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/', '$1.$2.$3/$4-$5', $cnpj);
    }
    return $cnpj;
}

function format_phone($phone) {
    $phone = preg_replace('/[^0-9]/', '', $phone);
    if(strlen($phone) == 11) {
        return preg_replace('/(\d{2})(\d{5})(\d{4})/', '($1) $2-$3', $phone);
    } elseif(strlen($phone) == 10) {
        return preg_replace('/(\d{2})(\d{4})(\d{4})/', '($1) $2-$3', $phone);
    }
    return $phone;
}

function format_currency($value) {
    return 'R$ ' . number_format($value, 2, ',', '.');
}

function format_date($date) {
    if($date) {
        return date('d/m/Y', strtotime($date));
    }
    return '';
}

function show_message($type, $message) {
    $alert_type = $type == 'success' ? 'alert-success' : 'alert-danger';
    return '<div class="alert ' . $alert_type . ' alert-dismissible fade show" role="alert">
                ' . $message . '
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>';
}
?>