<?php if(is_logged_in()): ?>
<div class="container-fluid">
    <div class="row">
        <nav class="col-md-3 col-lg-2 d-md-block bg-dark sidebar">
            <div class="position-sticky pt-3">
                <div class="text-center mb-4">
                    <i class="fas fa-hand-holding-heart fa-3x text-white"></i>
                    <h5 class="text-white mt-2">Sistema ONG</h5>
                    <small class="text-muted">Olá, <?php echo $_SESSION['user_nome']; ?></small>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'instituicoes.php' ? 'active' : ''; ?>" href="instituicoes.php">
                            <i class="fas fa-building me-2"></i> Instituições
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'documentos.php' ? 'active' : ''; ?>" href="documentos.php">
                            <i class="fas fa-file-alt me-2"></i> Documentos
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'relatorios.php' ? 'active' : ''; ?>" href="relatorios.php">
                            <i class="fas fa-chart-line me-2"></i> Relatórios
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white <?php echo basename($_SERVER['PHP_SELF']) == 'perfil.php' ? 'active' : ''; ?>" href="perfil.php">
                            <i class="fas fa-user me-2"></i> Perfil
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-danger" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i> Sair
                        </a>
                    </li>
                </ul>
            </div>
        </nav>
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
<?php endif; ?>