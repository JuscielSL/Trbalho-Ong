<?php
require_once 'includes/functions.php';

if(is_logged_in()) {
    header('Location: dashboard.php');
    exit();
}

$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';
    
    $response = api_request('auth/login', 'POST', ['email' => $email, 'senha' => $senha]);
    
    if($response['status'] == 200 && isset($response['data']['success'])) {
        $_SESSION['token'] = $response['data']['token'];
        $_SESSION['user_id'] = $response['data']['user']['id'];
        $_SESSION['user_nome'] = $response['data']['user']['nome'];
        $_SESSION['user_email'] = $response['data']['user']['email'];
        $_SESSION['user_perfil'] = $response['data']['user']['perfil'];
        
        header('Location: dashboard.php');
        exit();
    } else {
        $error = $response['data']['error'] ?? 'Email ou senha inválidos';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistema ONG</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            padding: 40px;
            width: 100%;
            max-width: 450px;
        }
        .login-icon {
            text-align: center;
            margin-bottom: 30px;
        }
        .login-icon i {
            font-size: 60px;
            color: #667eea;
        }
        .btn-login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            width: 100%;
            padding: 12px;
            font-size: 16px;
            font-weight: bold;
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="login-icon">
            <i class="fas fa-hand-holding-heart"></i>
            <h3 class="mt-3">Sistema ONG</h3>
            <p class="text-muted">Gestão de Instituições</p>
        </div>
        
        <?php if($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Senha</label>
                <input type="password" name="senha" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary btn-login">
                <i class="fas fa-sign-in-alt me-2"></i> Entrar
            </button>
        </form>
        
        <div class="text-center mt-3">
            <small class="text-muted">Credenciais padrão: admin@ong.com / 123456</small>
        </div>
    </div>
</body>
</html>