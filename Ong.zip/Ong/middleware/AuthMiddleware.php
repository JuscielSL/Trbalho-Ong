<?php
require_once __DIR__ . '/../models/SessaoUsuario.php';

class AuthMiddleware {
    private $sessaoUsuario;
    
    public function __construct($db) {
        $this->sessaoUsuario = new SessaoUsuario($db);
    }
    
    public function authenticate() {
        $headers = getallheaders();
        
        if(!isset($headers['Authorization'])) {
            http_response_code(401);
            echo json_encode(['error' => 'Token não fornecido']);
            exit();
        }
        
        $token = str_replace('Bearer ', '', $headers['Authorization']);
        $user = $this->sessaoUsuario->validateToken($token);
        
        if(!$user) {
            http_response_code(401);
            echo json_encode(['error' => 'Token inválido ou expirado']);
            exit();
        }
        
        return $user;
    }
    
    public function checkPermission($user, $required_perfil) {
        $perfis = ['usuario', 'coordenador', 'financeiro', 'admin'];
        $user_level = array_search($user['perfil'], $perfis);
        $required_level = array_search($required_perfil, $perfis);
        
        if($user_level < $required_level) {
            http_response_code(403);
            echo json_encode(['error' => 'Permissão negada']);
            exit();
        }
        
        return true;
    }
}
?>