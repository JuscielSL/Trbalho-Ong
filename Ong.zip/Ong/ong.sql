DROP DATABASE IF EXISTS ong;
CREATE DATABASE ong CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ong;

-- =====================================================
--    USUÁRIOS DO SISTEMA
-- =====================================================

CREATE TABLE usuario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    perfil ENUM('admin', 'financeiro', 'coordenador', 'usuario') DEFAULT 'usuario',
    ativo BOOLEAN DEFAULT TRUE,
    ultimo_login DATETIME NULL,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =====================================================
--    SESSÕES DE USUÁRIOS
-- =====================================================

CREATE TABLE sessao_usuario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    token VARCHAR(255) NOT NULL,
    ip VARCHAR(45),
    navegador VARCHAR(255),
    data_login DATETIME DEFAULT CURRENT_TIMESTAMP,
    data_expiracao DATETIME,
    CONSTRAINT fk_sessao_usuario FOREIGN KEY (usuario_id) REFERENCES usuario(id) ON DELETE CASCADE
);

-- =====================================================
--    LOGS DO SISTEMA
-- =====================================================

CREATE TABLE log_sistema (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT,
    acao VARCHAR(255),
    tabela_afetada VARCHAR(100),
    descricao TEXT,
    data_acao DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_log_usuario FOREIGN KEY (usuario_id) REFERENCES usuario(id) ON DELETE SET NULL
);

-- =====================================================
--    INSTITUIÇÃO
-- =====================================================

CREATE TABLE instituicao (
    id INT AUTO_INCREMENT PRIMARY KEY,
    razao_social VARCHAR(150) NOT NULL,
    nome_fantasia VARCHAR(150),
    cnpj VARCHAR(18) UNIQUE NOT NULL,
    endereco VARCHAR(255),
    cidade VARCHAR(100),
    estado VARCHAR(2),
    cep VARCHAR(10),
    telefone_principal VARCHAR(20),
    email VARCHAR(100),
    site VARCHAR(150),
    descricao TEXT,
    data_fundacao DATE,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =====================================================
--    TELEFONES
-- =====================================================

CREATE TABLE telefone (
    id INT AUTO_INCREMENT PRIMARY KEY,
    instituicao_id INT NOT NULL,
    numero VARCHAR(20) NOT NULL,
    tipo ENUM('celular', 'fixo', 'whatsapp') DEFAULT 'celular',
    CONSTRAINT fk_telefone_instituicao FOREIGN KEY (instituicao_id) REFERENCES instituicao(id) ON DELETE CASCADE
);

-- =====================================================
--    CONTAS BANCÁRIAS
-- =====================================================

CREATE TABLE conta_bancaria (
    id INT AUTO_INCREMENT PRIMARY KEY,
    instituicao_id INT NOT NULL,
    banco VARCHAR(100) NOT NULL,
    agencia VARCHAR(20),
    conta VARCHAR(30),
    operacao VARCHAR(10),
    tipo_conta ENUM('corrente', 'poupanca', 'pagamento') DEFAULT 'corrente',
    pix VARCHAR(150),
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_conta_instituicao FOREIGN KEY (instituicao_id) REFERENCES instituicao(id) ON DELETE CASCADE
);

-- =====================================================
--    DIRIGENTES
-- =====================================================

CREATE TABLE dirigente (
    id INT AUTO_INCREMENT PRIMARY KEY,
    instituicao_id INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(14),
    cargo VARCHAR(100),
    telefone VARCHAR(20),
    email VARCHAR(100),
    inicio_mandato DATE,
    fim_mandato DATE,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_dirigente_instituicao FOREIGN KEY (instituicao_id) REFERENCES instituicao(id) ON DELETE CASCADE
);

-- =====================================================
--    COORDENADORES
-- =====================================================

CREATE TABLE coordenador (
    id INT AUTO_INCREMENT PRIMARY KEY,
    instituicao_id INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    setor VARCHAR(100),
    telefone VARCHAR(20),
    email VARCHAR(100),
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_coordenador_instituicao FOREIGN KEY (instituicao_id) REFERENCES instituicao(id) ON DELETE CASCADE
);

-- =====================================================
--    DOCUMENTOS
-- =====================================================

CREATE TABLE documento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    instituicao_id INT NOT NULL,
    tipo_documento ENUM(
        'Estatuto Social',
        'Cadastro CNPJ',
        'Certificacoes',
        'Licenciamentos',
        'Ata de Eleicao',
        'Certidoes Negativas',
        'Convenios Publicos',
        'Parcerias Privadas'
    ) NOT NULL,
    nome_arquivo VARCHAR(255) NOT NULL,
    caminho_arquivo VARCHAR(255) NOT NULL,
    tipo_arquivo VARCHAR(20),
    extensao VARCHAR(10),
    tamanho_arquivo BIGINT,
    validade DATE,
    enviado_por INT,
    data_upload DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_documento_instituicao FOREIGN KEY (instituicao_id) REFERENCES instituicao(id) ON DELETE CASCADE,
    CONSTRAINT fk_documento_usuario FOREIGN KEY (enviado_por) REFERENCES usuario(id) ON DELETE SET NULL
);

-- =====================================================
--    PARCERIAS PÚBLICAS
-- =====================================================

CREATE TABLE parceria_publica (
    id INT AUTO_INCREMENT PRIMARY KEY,
    instituicao_id INT NOT NULL,
    orgao_publico VARCHAR(150) NOT NULL,
    numero_convenio VARCHAR(100),
    descricao TEXT,
    valor DECIMAL(12,2),
    data_inicio DATE,
    data_fim DATE,
    status_parceria ENUM('ativa', 'encerrada', 'suspensa') DEFAULT 'ativa',
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_parceria_publica FOREIGN KEY (instituicao_id) REFERENCES instituicao(id) ON DELETE CASCADE
);

-- =====================================================
--    PARCERIAS PRIVADAS
-- =====================================================

CREATE TABLE parceria_privada (
    id INT AUTO_INCREMENT PRIMARY KEY,
    instituicao_id INT NOT NULL,
    empresa VARCHAR(150) NOT NULL,
    descricao TEXT,
    valor DECIMAL(12,2),
    data_inicio DATE,
    data_fim DATE,
    status_parceria ENUM('ativa', 'encerrada', 'suspensa') DEFAULT 'ativa',
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_parceria_privada FOREIGN KEY (instituicao_id) REFERENCES instituicao(id) ON DELETE CASCADE
);

-- =====================================================
--    ÍNDICES PARA PERFORMANCE
-- =====================================================

CREATE INDEX idx_usuario_email ON usuario(email);
CREATE INDEX idx_instituicao_cnpj ON instituicao(cnpj);
CREATE INDEX idx_documento_tipo ON documento(tipo_documento);
CREATE INDEX idx_documento_validade ON documento(validade);
CREATE INDEX idx_dirigente_nome ON dirigente(nome);

-- =====================================================
--    VIEW RELATÓRIO GERAL
-- =====================================================

CREATE VIEW vw_relatorio_instituicao AS
SELECT
    i.id,
    i.razao_social,
    i.nome_fantasia,
    i.cnpj,
    i.email,
    i.telefone_principal,
    i.cidade,
    i.estado,
    COUNT(DISTINCT d.id)   AS total_dirigentes,
    COUNT(DISTINCT c.id)   AS total_coordenadores,
    COUNT(DISTINCT doc.id) AS total_documentos,
    COUNT(DISTINCT pp.id)  AS total_parcerias_publicas,
    COUNT(DISTINCT pv.id)  AS total_parcerias_privadas
FROM instituicao i
LEFT JOIN dirigente      d   ON d.instituicao_id   = i.id
LEFT JOIN coordenador    c   ON c.instituicao_id   = i.id
LEFT JOIN documento      doc ON doc.instituicao_id = i.id
LEFT JOIN parceria_publica  pp ON pp.instituicao_id = i.id
LEFT JOIN parceria_privada  pv ON pv.instituicao_id = i.id
GROUP BY i.id;

-- =====================================================
--    VIEW DOCUMENTOS VENCIDOS
-- =====================================================

CREATE VIEW vw_documentos_vencidos AS
SELECT
    i.razao_social,
    d.tipo_documento,
    d.validade
FROM documento d
INNER JOIN instituicao i ON i.id = d.instituicao_id
WHERE d.validade IS NOT NULL
  AND d.validade < CURDATE();

-- =====================================================
--    PROCEDURE RELATÓRIO DE PARCERIAS
-- =====================================================

DELIMITER $$

CREATE PROCEDURE sp_relatorio_parcerias()
BEGIN
    SELECT
        i.razao_social,
        IFNULL(SUM(pp.valor), 0) AS total_publico,
        IFNULL(SUM(pv.valor), 0) AS total_privado
    FROM instituicao i
    LEFT JOIN parceria_publica  pp ON pp.instituicao_id = i.id
    LEFT JOIN parceria_privada  pv ON pv.instituicao_id = i.id
    GROUP BY i.id;
END $$

DELIMITER ;

-- =====================================================
--    USUÁRIO ADMINISTRADOR PADRÃO  (senha: 123456)
-- =====================================================

INSERT INTO usuario (nome, email, senha, perfil)
VALUES (
    'Administrador',
    'admin@ong.com',
    '$2y$10$wH7H6B0k0D2x8V2qLQ8X3O1J8xjQ4p3dR7dKxY5mG2L1nS6pA9e1W',
    'admin'
);
