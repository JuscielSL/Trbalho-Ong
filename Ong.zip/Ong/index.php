<?php
require_once 'config/cors.php';
require_once 'config/database.php';
require_once 'middleware/AuthMiddleware.php';
require_once 'controllers/AuthController.php';
require_once 'controllers/InstituicaoController.php';
require_once 'controllers/DocumentoController.php';
require_once 'controllers/RelatorioController.php';

$database = new Database();
$db = $database->getConnection();

$request_method = $_SERVER['REQUEST_METHOD'];
$request_uri    = $_SERVER['REQUEST_URI'];
$path           = parse_url($request_uri, PHP_URL_PATH);

// Remove o nome da pasta do projeto do path (ex: /Ong/ → /)
$script_dir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
if ($script_dir && strpos($path, $script_dir) === 0) {
    $path = substr($path, strlen($script_dir));
}

$path_parts = explode('/', trim($path, '/'));
$resource   = $path_parts[0] ?? '';
$id         = $path_parts[1] ?? null;

// Rotas públicas
if ($resource === 'auth' && $request_method === 'POST' && ($path_parts[1] ?? '') === 'login') {
    $authController = new AuthController($db);
    $authController->login();
    exit();
}

// Middleware para rotas protegidas
$authMiddleware = new AuthMiddleware($db);
$user = $authMiddleware->authenticate();

// Rotas protegidas
switch ($resource) {

    case 'auth':
        if (($path_parts[1] ?? '') === 'logout') {
            $authController = new AuthController($db);
            $authController->logout();
        }
        break;

    case 'instituicoes':
        $controller = new InstituicaoController($db, $user['id']);
        switch ($request_method) {
            case 'GET':
                if ($id) {
                    $controller->getById($id);
                } else {
                    $controller->getAll();
                }
                break;
            case 'POST':
                $controller->create();
                break;
            case 'PUT':
                if ($id) $controller->update($id);
                break;
            case 'DELETE':
                if ($id) $controller->delete($id);
                break;
        }
        break;

    case 'documentos':
        $controller = new DocumentoController($db, $user['id']);
        if ($request_method === 'POST' && isset($_FILES['arquivo'])) {
            $instituicao_id = $_GET['instituicao_id'] ?? null;
            if ($instituicao_id) {
                $controller->upload($instituicao_id);
            }
        } elseif ($request_method === 'GET' && ($path_parts[1] ?? '') === 'vencidos') {
            $controller->getVencidos();
        } elseif ($request_method === 'DELETE' && $id) {
            $controller->delete($id);
        }
        break;

    case 'relatorios':
        $controller = new RelatorioController($db);
        switch ($path_parts[1] ?? '') {
            case 'geral':
                $controller->getRelatorioGeral();
                break;
            case 'financeiro':
                $controller->getRelatorioFinanceiro();
                break;
            case 'documentos-vencidos':
                $controller->getDocumentosVencidos();
                break;
            default:
                http_response_code(404);
                echo json_encode(['erro' => 'Relatório não encontrado']);
                break;
        }
        break;

    default:
        http_response_code(404);
        echo json_encode(['erro' => 'Rota não encontrada']);
        break;
}