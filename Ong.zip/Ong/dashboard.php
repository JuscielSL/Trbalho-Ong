<?php
require_once 'includes/functions.php';
redirect_if_not_logged_in();
include 'includes/header.php';
include 'includes/sidebar.php';

// Buscar dados para o dashboard
$instituicoes_response = api_request('instituicoes');
$relatorio_response = api_request('relatorios/geral');
$docs_vencidos_response = api_request('relatorios/documentos-vencidos');

$total_instituicoes = isset($instituicoes_response['data']) ? count($instituicoes_response['data']) : 0;
$total_parcerias_publicas = 0;
$total_parcerias_privadas = 0;

if(isset($relatorio_response['data']) && is_array($relatorio_response['data'])) {
    foreach($relatorio_response['data'] as $item) {
        $total_parcerias_publicas += $item['total_parcerias_publicas'] ?? 0;
        $total_parcerias_privadas += $item['total_parcerias_privadas'] ?? 0;
    }
}

$total_docs_vencidos = isset($docs_vencidos_response['data']) ? count($docs_vencidos_response['data']) : 0;
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Dashboard</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <div class="btn-group me-2">
            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="window.location.reload()">
                <i class="fas fa-sync-alt"></i> Atualizar
            </button>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-3 mb-4">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title">Instituições</h6>
                        <h2 class="mb-0"><?php echo $total_instituicoes; ?></h2>
                    </div>
                    <i class="fas fa-building fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card bg-success text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title">Parcerias Públicas</h6>
                        <h2 class="mb-0"><?php echo $total_parcerias_publicas; ?></h2>
                    </div>
                    <i class="fas fa-handshake fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card bg-info text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title">Parcerias Privadas</h6>
                        <h2 class="mb-0"><?php echo $total_parcerias_privadas; ?></h2>
                    </div>
                    <i class="fas fa-chart-line fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card bg-warning text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title">Documentos Vencidos</h6>
                        <h2 class="mb-0"><?php echo $total_docs_vencidos; ?></h2>
                    </div>
                    <i class="fas fa-file-excel fa-3x opacity-50"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12 mb-4">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-building me-2"></i> Últimas Instituições Cadastradas</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Razão Social</th>
                                <th>CNPJ</th>
                                <th>Cidade</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($instituicoes_response['data']) && is_array($instituicoes_response['data'])): ?>
                                <?php foreach(array_slice($instituicoes_response['data'], 0, 5) as $inst): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($inst['razao_social']); ?></td>
                                        <td><?php echo format_cnpj($inst['cnpj']); ?></td>
                                        <td><?php echo htmlspecialchars($inst['cidade']); ?></td>
                                        <td><?php echo htmlspecialchars($inst['estado']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>