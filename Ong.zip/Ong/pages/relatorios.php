<?php
require_once '../includes/functions.php';
redirect_if_not_logged_in();
include '../includes/header.php';
include '../includes/sidebar.php';

// Buscar relatórios
$relatorio_geral = api_request('relatorios/geral');
$relatorio_financeiro = api_request('relatorios/financeiro');
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Relatórios</h1>
</div>

<div class="row">
    <div class="col-md-12 mb-4">
        <div class="card">
            <div class="card-header bg-success text-white">
                <h5><i class="fas fa-chart-bar me-2"></i> Relatório Geral de Instituições</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped" id="tabelaRelatorio">
                        <thead>
                            <tr>
                                <th>Instituição</th>
                                <th>CNPJ</th>
                                <th>Dirigentes</th>
                                <th>Coordenadores</th>
                                <th>Documentos</th>
                                <th>Parcerias Públicas</th>
                                <th>Parcerias Privadas</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($relatorio_geral['data']) && is_array($relatorio_geral['data'])): ?>
                                <?php foreach($relatorio_geral['data'] as $item): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($item['razao_social']); ?></td>
                                        <td><?php echo format_cnpj($item['cnpj']); ?></td>
                                        <td><?php echo $item['total_dirigentes']; ?></td>
                                        <td><?php echo $item['total_coordenadores']; ?></td>
                                        <td><?php echo $item['total_documentos']; ?></td>
                                        <td><?php echo $item['total_parcerias_publicas']; ?></td>
                                        <td><?php echo $item['total_parcerias_privadas']; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-12 mb-4">
        <div class="card">
            <div class="card-header bg-info text-white">
                <h5><i class="fas fa-coins me-2"></i> Relatório Financeiro de Parcerias</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Instituição</th>
                                <th>Total Parcerias Públicas</th>
                                <th>Total Parcerias Privadas</th>
                                <th>Total Geral</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($relatorio_financeiro['data']) && is_array($relatorio_financeiro['data'])): ?>
                                <?php foreach($relatorio_financeiro['data'] as $item): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($item['razao_social']); ?></td>
                                        <td><?php echo format_currency($item['total_publico']); ?></td>
                                        <td><?php echo format_currency($item['total_privado']); ?></td>
                                        <td><?php echo format_currency($item['total_publico'] + $item['total_privado']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#tabelaRelatorio').DataTable({
        language: {
            url: '//cdn.datatables.net/plug-ins/1.11.5/i18n/pt-BR.json'
        },
        pageLength: 25
    });
});
</script>

<?php include '../includes/footer.php'; ?>