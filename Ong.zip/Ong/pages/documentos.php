<?php
require_once '../includes/functions.php';
redirect_if_not_logged_in();
include '../includes/header.php';
include '../includes/sidebar.php';

// Buscar instituições para o select
$inst_response = api_request('instituicoes');
$instituicoes = isset($inst_response['data']) ? $inst_response['data'] : [];

// Buscar documentos vencidos
$vencidos_response = api_request('relatorios/documentos-vencidos');
$documentos_vencidos = isset($vencidos_response['data']) ? $vencidos_response['data'] : [];
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Documentos</h1>
</div>

<div class="row">
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5><i class="fas fa-upload me-2"></i> Upload de Documento</h5>
            </div>
            <div class="card-body">
                <form id="formUpload" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label>Instituição *</label>
                        <select class="form-control" id="instituicao_id" required>
                            <option value="">Selecione...</option>
                            <?php foreach($instituicoes as $inst): ?>
                                <option value="<?php echo $inst['id']; ?>">
                                    <?php echo htmlspecialchars($inst['razao_social']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label>Tipo de Documento *</label>
                        <select class="form-control" id="tipo_documento" required>
                            <option value="">Selecione...</option>
                            <option value="Estatuto Social">Estatuto Social</option>
                            <option value="Cadastro CNPJ">Cadastro CNPJ</option>
                            <option value="Certificacoes">Certificações</option>
                            <option value="Licenciamentos">Licenciamentos</option>
                            <option value="Ata de Eleicao">Ata de Eleição</option>
                            <option value="Certidoes Negativas">Certidões Negativas</option>
                            <option value="Convenios Publicos">Convênios Públicos</option>
                            <option value="Parcerias Privadas">Parcerias Privadas</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label>Arquivo *</label>
                        <input type="file" class="form-control" id="arquivo" required>
                    </div>
                    <div class="mb-3">
                        <label>Data de Validade</label>
                        <input type="date" class="form-control" id="validade">
                    </div>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-upload"></i> Enviar Documento
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header bg-warning">
                <h5><i class="fas fa-exclamation-triangle me-2"></i> Documentos Vencidos</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Instituição</th>
                                <th>Tipo</th>
                                <th>Validade</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($documentos_vencidos) > 0): ?>
                                <?php foreach($documentos_vencidos as $doc): ?>
                                    <tr class="table-danger">
                                        <td><?php echo htmlspecialchars($doc['razao_social']); ?></td>
                                        <td><?php echo htmlspecialchars($doc['tipo_documento']); ?></td>
                                        <td><?php echo format_date($doc['validade']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="3" class="text-center">Nenhum documento vencido</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$('#formUpload').on('submit', function(e) {
    e.preventDefault();
    
    var formData = new FormData();
    formData.append('instituicao_id', $('#instituicao_id').val());
    formData.append('tipo_documento', $('#tipo_documento').val());
    formData.append('validade', $('#validade').val());
    formData.append('arquivo', $('#arquivo')[0].files[0]);
    
    var instituicao_id = $('#instituicao_id').val();
    
    $.ajax({
        url: '../api/proxy.php?endpoint=documentos&instituicao_id=' + instituicao_id,
        method: 'POST',
        headers: {
            'Authorization': 'Bearer ' + '<?php echo $_SESSION['token']; ?>'
        },
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            alert('Documento enviado com sucesso!');
            location.reload();
        },
        error: function(xhr) {
            alert('Erro ao enviar documento: ' + xhr.responseText);
        }
    });
});
</script>

<?php include '../includes/footer.php'; ?>