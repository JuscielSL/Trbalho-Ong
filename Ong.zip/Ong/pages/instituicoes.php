<?php
require_once '../includes/functions.php';
redirect_if_not_logged_in();
include '../includes/header.php';
include '../includes/sidebar.php';

// Buscar instituições
$response = api_request('instituicoes');
$instituicoes = isset($response['data']) ? $response['data'] : [];
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Instituições</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalInstituicao" onclick="clearForm()">
            <i class="fas fa-plus"></i> Nova Instituição
        </button>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table id="tabelaInstituicoes" class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Razão Social</th>
                        <th>CNPJ</th>
                        <th>Cidade/UF</th>
                        <th>Telefone</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($instituicoes as $inst): ?>
                    <tr>
                        <td><?php echo $inst['id']; ?></td>
                        <td><?php echo htmlspecialchars($inst['razao_social']); ?></td>
                        <td><?php echo format_cnpj($inst['cnpj']); ?></td>
                        <td><?php echo htmlspecialchars($inst['cidade'] . '/' . $inst['estado']); ?></td>
                        <td><?php echo format_phone($inst['telefone_principal']); ?></td>
                        <td>
                            <button class="btn btn-sm btn-info" onclick="verInstituicao(<?php echo $inst['id']; ?>)">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="btn btn-sm btn-warning" onclick="editarInstituicao(<?php echo $inst['id']; ?>)">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="excluirInstituicao(<?php echo $inst['id']; ?>)">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal para cadastro/edição -->
<div class="modal fade" id="modalInstituicao" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">Nova Instituição</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="formInstituicao">
                <input type="hidden" id="instituicao_id" name="id">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label>Razão Social *</label>
                            <input type="text" class="form-control" id="razao_social" name="razao_social" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Nome Fantasia</label>
                            <input type="text" class="form-control" id="nome_fantasia" name="nome_fantasia">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>CNPJ *</label>
                            <input type="text" class="form-control" id="cnpj" name="cnpj" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Email</label>
                            <input type="email" class="form-control" id="email" name="email">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Telefone Principal</label>
                            <input type="text" class="form-control" id="telefone_principal" name="telefone_principal">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Site</label>
                            <input type="text" class="form-control" id="site" name="site">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label>Endereço</label>
                            <input type="text" class="form-control" id="endereco" name="endereco">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label>Cidade</label>
                            <input type="text" class="form-control" id="cidade" name="cidade">
                        </div>
                        <div class="col-md-2 mb-3">
                            <label>UF</label>
                            <select class="form-control" id="estado" name="estado">
                                <option value="">Selecione</option>
                                <option value="AC">AC</option><option value="AL">AL</option><option value="AP">AP</option>
                                <option value="AM">AM</option><option value="BA">BA</option><option value="CE">CE</option>
                                <option value="DF">DF</option><option value="ES">ES</option><option value="GO">GO</option>
                                <option value="MA">MA</option><option value="MT">MT</option><option value="MS">MS</option>
                                <option value="MG">MG</option><option value="PA">PA</option><option value="PB">PB</option>
                                <option value="PR">PR</option><option value="PE">PE</option><option value="PI">PI</option>
                                <option value="RJ">RJ</option><option value="RN">RN</option><option value="RS">RS</option>
                                <option value="RO">RO</option><option value="RR">RR</option><option value="SC">SC</option>
                                <option value="SP">SP</option><option value="SE">SE</option><option value="TO">TO</option>
                            </select>
                        </div>
                        <div class="col-md-2 mb-3">
                            <label>CEP</label>
                            <input type="text" class="form-control" id="cep" name="cep">
                        </div>
                        <div class="col-md-12 mb-3">
                            <label>Descrição</label>
                            <textarea class="form-control" id="descricao" name="descricao" rows="3"></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Data de Fundação</label>
                            <input type="date" class="form-control" id="data_fundacao" name="data_fundacao">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal para visualizar detalhes -->
<div class="modal fade" id="modalVisualizar" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detalhes da Instituição</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="detalhesConteudo">
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#tabelaInstituicoes').DataTable({
        language: {
            url: '//cdn.datatables.net/plug-ins/1.11.5/i18n/pt-BR.json'
        }
    });
    
    $('#cnpj').mask('00.000.000/0000-00');
    $('#telefone_principal').mask('(00) 00000-0000');
    $('#cep').mask('00000-000');
    
    $('#formInstituicao').on('submit', function(e) {
        e.preventDefault();
        salvarInstituicao();
    });
});

function clearForm() {
    $('#formInstituicao')[0].reset();
    $('#instituicao_id').val('');
    $('#modalTitle').text('Nova Instituição');
}

function salvarInstituicao() {
    var id = $('#instituicao_id').val();
    var data = {
        razao_social: $('#razao_social').val(),
        nome_fantasia: $('#nome_fantasia').val(),
        cnpj: $('#cnpj').val(),
        endereco: $('#endereco').val(),
        cidade: $('#cidade').val(),
        estado: $('#estado').val(),
        cep: $('#cep').val(),
        telefone_principal: $('#telefone_principal').val(),
        email: $('#email').val(),
        site: $('#site').val(),
        descricao: $('#descricao').val(),
        data_fundacao: $('#data_fundacao').val()
    };
    
    var url = id ? '../api/proxy.php?endpoint=instituicoes/' + id : '../api/proxy.php?endpoint=instituicoes';
    var method = id ? 'PUT' : 'POST';
    
    $.ajax({
        url: url,
        method: method,
        contentType: 'application/json',
        headers: {
            'Authorization': 'Bearer ' + '<?php echo $_SESSION['token']; ?>'
        },
        data: JSON.stringify(data),
        success: function(response) {
            $('#modalInstituicao').modal('hide');
            location.reload();
        },
        error: function(xhr) {
            alert('Erro ao salvar instituição: ' + xhr.responseText);
        }
    });
}

function verInstituicao(id) {
    $.ajax({
        url: '../api/proxy.php?endpoint=instituicoes/' + id,
        method: 'GET',
        headers: {
            'Authorization': 'Bearer ' + '<?php echo $_SESSION['token']; ?>'
        },
        success: function(data) {
            var html = '<table class="table">';
            html += '<tr><th>Razão Social:</th><td>' + data.razao_social + '</td></tr>';
            html += '<tr><th>Nome Fantasia:</th><td>' + (data.nome_fantasia || '-') + '</td></tr>';
            html += '<tr><th>CNPJ:</th><td>' + formatarCNPJ(data.cnpj) + '</td></tr>';
            html += '<tr><th>Endereço:</th><td>' + (data.endereco || '-') + '</td></tr>';
            html += '<tr><th>Cidade/UF:</th><td>' + (data.cidade || '-') + '/' + (data.estado || '-') + '</td></tr>';
            html += '<tr><th>Telefone:</th><td>' + formatarTelefone(data.telefone_principal) + '</td></tr>';
            html += '<tr><th>Email:</th><td>' + (data.email || '-') + '</td></tr>';
            html += '<tr><th>Site:</th><td>' + (data.site || '-') + '</td></tr>';
            html += '<tr><th>Descrição:</th><td>' + (data.descricao || '-') + '</td></tr>';
            html += '</table>';
            
            if(data.documentos && data.documentos.length > 0) {
                html += '<h6 class="mt-3">Documentos</h6><ul>';
                data.documentos.forEach(function(doc) {
                    html += '<li>' + doc.tipo_documento + ' - ' + doc.nome_arquivo + '</li>';
                });
                html += '</ul>';
            }
            
            $('#detalhesConteudo').html(html);
            $('#modalVisualizar').modal('show');
        }
    });
}

function editarInstituicao(id) {
    $.ajax({
        url: '../api/proxy.php?endpoint=instituicoes/' + id,
        method: 'GET',
        headers: {
            'Authorization': 'Bearer ' + '<?php echo $_SESSION['token']; ?>'
        },
        success: function(data) {
            $('#instituicao_id').val(data.id);
            $('#razao_social').val(data.razao_social);
            $('#nome_fantasia').val(data.nome_fantasia);
            $('#cnpj').val(formatarCNPJ(data.cnpj));
            $('#endereco').val(data.endereco);
            $('#cidade').val(data.cidade);
            $('#estado').val(data.estado);
            $('#cep').val(data.cep);
            $('#telefone_principal').val(formatarTelefone(data.telefone_principal));
            $('#email').val(data.email);
            $('#site').val(data.site);
            $('#descricao').val(data.descricao);
            $('#data_fundacao').val(data.data_fundacao);
            $('#modalTitle').text('Editar Instituição');
            $('#modalInstituicao').modal('show');
        }
    });
}

function excluirInstituicao(id) {
    if(confirm('Tem certeza que deseja excluir esta instituição?')) {
        $.ajax({
            url: '../api/proxy.php?endpoint=instituicoes/' + id,
            method: 'DELETE',
            headers: {
                'Authorization': 'Bearer ' + '<?php echo $_SESSION['token']; ?>'
            },
            success: function(response) {
                location.reload();
            },
            error: function(xhr) {
                alert('Erro ao excluir instituição');
            }
        });
    }
}

function formatarCNPJ(cnpj) {
    cnpj = cnpj.replace(/\D/g, '');
    return cnpj.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
}

function formatarTelefone(telefone) {
    if(!telefone) return '';
    telefone = telefone.replace(/\D/g, '');
    if(telefone.length === 11) {
        return telefone.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    }
    return telefone;
}
</script>

<?php include '../includes/footer.php'; ?>