<?php
class Instituicao {
    private $conn;
    private $table_name = "instituicao";

    public $id;
    public $razao_social;
    public $nome_fantasia;
    public $cnpj;
    public $endereco;
    public $cidade;
    public $estado;
    public $cep;
    public $telefone_principal;
    public $email;
    public $site;
    public $descricao;
    public $data_fundacao;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create() {
        $query = "INSERT INTO " . $this->table_name . "
                  SET razao_social = :razao_social, nome_fantasia = :nome_fantasia,
                      cnpj = :cnpj, endereco = :endereco, cidade = :cidade,
                      estado = :estado, cep = :cep, telefone_principal = :telefone_principal,
                      email = :email, site = :site, descricao = :descricao,
                      data_fundacao = :data_fundacao";

        $stmt = $this->conn->prepare($query);
        
        $this->razao_social = htmlspecialchars(strip_tags($this->razao_social));
        $this->cnpj = preg_replace('/[^0-9]/', '', $this->cnpj);
        
        $stmt->bindParam(":razao_social", $this->razao_social);
        $stmt->bindParam(":nome_fantasia", $this->nome_fantasia);
        $stmt->bindParam(":cnpj", $this->cnpj);
        $stmt->bindParam(":endereco", $this->endereco);
        $stmt->bindParam(":cidade", $this->cidade);
        $stmt->bindParam(":estado", $this->estado);
        $stmt->bindParam(":cep", $this->cep);
        $stmt->bindParam(":telefone_principal", $this->telefone_principal);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":site", $this->site);
        $stmt->bindParam(":descricao", $this->descricao);
        $stmt->bindParam(":data_fundacao", $this->data_fundacao);
        
        if($stmt->execute()) {
            return $this->conn->lastInsertId();
        }
        return false;
    }

    public function findAll() {
        $query = "SELECT * FROM " . $this->table_name . " ORDER BY razao_social";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function findById($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function update() {
        $query = "UPDATE " . $this->table_name . "
                  SET razao_social = :razao_social, nome_fantasia = :nome_fantasia,
                      cnpj = :cnpj, endereco = :endereco, cidade = :cidade,
                      estado = :estado, cep = :cep, telefone_principal = :telefone_principal,
                      email = :email, site = :site, descricao = :descricao,
                      data_fundacao = :data_fundacao
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        
        $this->razao_social = htmlspecialchars(strip_tags($this->razao_social));
        $this->cnpj = preg_replace('/[^0-9]/', '', $this->cnpj);
        
        $stmt->bindParam(":razao_social", $this->razao_social);
        $stmt->bindParam(":nome_fantasia", $this->nome_fantasia);
        $stmt->bindParam(":cnpj", $this->cnpj);
        $stmt->bindParam(":endereco", $this->endereco);
        $stmt->bindParam(":cidade", $this->cidade);
        $stmt->bindParam(":estado", $this->estado);
        $stmt->bindParam(":cep", $this->cep);
        $stmt->bindParam(":telefone_principal", $this->telefone_principal);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":site", $this->site);
        $stmt->bindParam(":descricao", $this->descricao);
        $stmt->bindParam(":data_fundacao", $this->data_fundacao);
        $stmt->bindParam(":id", $this->id);
        
        return $stmt->execute();
    }

    public function delete($id) {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        return $stmt->execute();
    }
}
?>