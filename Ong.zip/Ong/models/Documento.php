<?php
class Documento {
    private $conn;
    private $table_name = "documento";

    public $id;
    public $instituicao_id;
    public $tipo_documento;
    public $nome_arquivo;
    public $caminho_arquivo;
    public $validade;
    public $enviado_por;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create() {
        $query = "INSERT INTO " . $this->table_name . "
                  SET instituicao_id = :instituicao_id, tipo_documento = :tipo_documento,
                      nome_arquivo = :nome_arquivo, caminho_arquivo = :caminho_arquivo,
                      validade = :validade, enviado_por = :enviado_por";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(":instituicao_id", $this->instituicao_id);
        $stmt->bindParam(":tipo_documento", $this->tipo_documento);
        $stmt->bindParam(":nome_arquivo", $this->nome_arquivo);
        $stmt->bindParam(":caminho_arquivo", $this->caminho_arquivo);
        $stmt->bindParam(":validade", $this->validade);
        $stmt->bindParam(":enviado_por", $this->enviado_por);
        
        return $stmt->execute();
    }

    public function findByInstituicao($instituicao_id) {
        $query = "SELECT d.*, u.nome as usuario_nome
                  FROM " . $this->table_name . " d
                  LEFT JOIN usuario u ON u.id = d.enviado_por
                  WHERE d.instituicao_id = :instituicao_id
                  ORDER BY d.data_upload DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":instituicao_id", $instituicao_id);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function findVencidos() {
        $query = "SELECT d.*, i.razao_social
                  FROM " . $this->table_name . " d
                  JOIN instituicao i ON i.id = d.instituicao_id
                  WHERE d.validade IS NOT NULL AND d.validade < CURDATE()";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function delete($id) {
        $query = "SELECT caminho_arquivo FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();
        $doc = $stmt->fetch();
        
        if($doc && file_exists($doc['caminho_arquivo'])) {
            unlink($doc['caminho_arquivo']);
        }
        
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        return $stmt->execute();
    }
}
?>