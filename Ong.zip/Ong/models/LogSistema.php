<?php
class LogSistema {
    private $conn;
    private $table_name = "log_sistema";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create($usuario_id, $acao, $tabela_afetada, $descricao) {
        $query = "INSERT INTO " . $this->table_name . "
                  SET usuario_id = :usuario_id, acao = :acao,
                      tabela_afetada = :tabela_afetada, descricao = :descricao";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":usuario_id", $usuario_id);
        $stmt->bindParam(":acao", $acao);
        $stmt->bindParam(":tabela_afetada", $tabela_afetada);
        $stmt->bindParam(":descricao", $descricao);
        
        return $stmt->execute();
    }

    public function findAll($limit = 100) {
        $query = "SELECT l.*, u.nome as usuario_nome
                  FROM " . $this->table_name . " l
                  LEFT JOIN usuario u ON u.id = l.usuario_id
                  ORDER BY l.data_acao DESC
                  LIMIT :limit";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":limit", $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
?>