<?php
class SessaoUsuario {
    private $conn;
    private $table_name = "sessao_usuario";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create($usuario_id, $token, $ip, $navegador) {
        $query = "INSERT INTO " . $this->table_name . "
                  SET usuario_id = :usuario_id, token = :token, ip = :ip,
                      navegador = :navegador, data_expiracao = DATE_ADD(NOW(), INTERVAL 24 HOUR)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":usuario_id", $usuario_id);
        $stmt->bindParam(":token", $token);
        $stmt->bindParam(":ip", $ip);
        $stmt->bindParam(":navegador", $navegador);
        
        return $stmt->execute();
    }

    public function validateToken($token) {
        $query = "SELECT s.*, u.nome, u.email, u.perfil
                  FROM " . $this->table_name . " s
                  JOIN usuario u ON u.id = s.usuario_id
                  WHERE s.token = :token AND s.data_expiracao > NOW() AND u.ativo = 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":token", $token);
        $stmt->execute();
        
        if($stmt->rowCount() > 0) {
            return $stmt->fetch();
        }
        return false;
    }

    public function logout($token) {
        $query = "DELETE FROM " . $this->table_name . " WHERE token = :token";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":token", $token);
        return $stmt->execute();
    }
}
?>