// Funções globais
function formatarMoeda(valor) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(valor);
}

function formatarData(data) {
    if(!data) return '';
    return new Date(data).toLocaleDateString('pt-BR');
}

function showToast(message, type = 'success') {
    const bgClass = type === 'success' ? 'bg-success' : 'bg-danger';
    const toast = $(`
        <div class="toast align-items-center text-white ${bgClass} border-0" role="alert">
            <div class="d-flex">
                <div class="toast-body">${message}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    `);
    
    $('.toast-container').append(toast);
    toast.toast('show');
    setTimeout(() => toast.remove(), 3000);
}

// Loading overlay
function showLoading() {
    $('body').append('<div class="loading-overlay"><div class="spinner-border text-primary"></div></div>');
}

function hideLoading() {
    $('.loading-overlay').remove();
}

// Inicializar tooltips
$(document).ready(function() {
    $('[data-bs-toggle="tooltip"]').tooltip();
});