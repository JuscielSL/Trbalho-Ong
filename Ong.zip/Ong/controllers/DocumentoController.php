<?php
require_once __DIR__ . '/../models/Documento.php';
require_once __DIR__ . '/../models/LogSistema.php';

class DocumentoController {
    private $documento;
    private $logSistema;
    private $userId;
    private $uploadDir;
    
    public function __construct($db, $userId) {
        $this->documento = new Documento($db);
        $this->logSistema = new LogSistema($db);
        $this->userId = $userId;
        $this->uploadDir = __DIR__ . '/../uploads/';
        
        if(!file_exists($this->uploadDir)) {
            mkdir($this->uploadDir, 0777, true);
        }
    }
    
    public function upload($instituicao_id) {
        if(!isset($_FILES['arquivo']) || $_FILES['arquivo']['error'] !== UPLOAD_ERR_OK) {
            http_response_code(400);
            echo json_encode(['error' => 'Erro no upload do arquivo']);
            return;
        }
        
        $tipo_documento = $_POST['tipo_documento'] ?? '';
        $validade = $_POST['validade'] ?? null;
        
        $extensao = pathinfo($_FILES['arquivo']['name'], PATHINFO_EXTENSION);
        $nome_arquivo = uniqid() . '.' . $extensao;
        $caminho_arquivo = $this->uploadDir . $nome_arquivo;
        
        if(move_uploaded_file($_FILES['arquivo']['tmp_name'], $caminho_arquivo)) {
            $this->documento->instituicao_id = $instituicao_id;
            $this->documento->tipo_documento = $tipo_documento;
            $this->documento->nome_arquivo = $_FILES['arquivo']['name'];
            $this->documento->caminho_arquivo = $caminho_arquivo;
            $this->documento->validade = $validade;
            $this->documento->enviado_por = $this->userId;
            
            if($this->documento->create()) {
                $this->logSistema->create($this->userId, 'UPLOAD', 'documento', "Upload de documento: {$tipo_documento}");
                echo json_encode(['success' => true, 'message' => 'Documento enviado com sucesso']);
            } else {
                unlink($caminho_arquivo);
                http_response_code(500);
                echo json_encode(['error' => 'Erro ao salvar documento no banco']);
            }
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Erro ao mover arquivo']);
        }
    }
    
    public function getVencidos() {
        $documentos = $this->documento->findVencidos();
        echo json_encode($documentos);
    }
    
    public function delete($id) {
        if($this->documento->delete($id)) {
            $this->logSistema->create($this->userId, 'DELETE', 'documento', "Excluído documento ID: {$id}");
            echo json_encode(['success' => true, 'message' => 'Documento excluído com sucesso']);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Erro ao excluir documento']);
        }
    }
}
?>