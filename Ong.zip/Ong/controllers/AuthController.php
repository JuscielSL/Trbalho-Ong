<?php
require_once __DIR__ . '/../models/Usuario.php';
require_once __DIR__ . '/../models/SessaoUsuario.php';
require_once __DIR__ . '/../models/LogSistema.php';

class AuthController {
    private $usuario;
    private $sessaoUsuario;
    private $logSistema;
    
    public function __construct($db) {
        $this->usuario = new Usuario($db);
        $this->sessaoUsuario = new SessaoUsuario($db);
        $this->logSistema = new LogSistema($db);
    }
    
    public function login() {
        $data = json_decode(file_get_contents("php://input"));
        
        if(!isset($data->email) || !isset($data->senha)) {
            http_response_code(400);
            echo json_encode(['error' => 'Email e senha são obrigatórios']);
            return;
        }
        
        $this->usuario->email = $data->email;
        $this->usuario->senha = $data->senha;
        
        $user = $this->usuario->login();
        
        if($user) {
            $token = bin2hex(random_bytes(32));
            $ip = $_SERVER['REMOTE_ADDR'] ?? null;
            $navegador = $_SERVER['HTTP_USER_AGENT'] ?? null;
            
            $this->sessaoUsuario->create($user['id'], $token, $ip, $navegador);
            $this->usuario->updateUltimoLogin($user['id']);
            
            $this->logSistema->create($user['id'], 'LOGIN', 'usuario', "Usuário {$user['email']} realizou login");
            
            echo json_encode([
                'success' => true,
                'token' => $token,
                'user' => [
                    'id' => $user['id'],
                    'nome' => $user['nome'],
                    'email' => $user['email'],
                    'perfil' => $user['perfil']
                ]
            ]);
        } else {
            http_response_code(401);
            echo json_encode(['error' => 'Email ou senha inválidos']);
        }
    }
    
    public function logout() {
        $headers = getallheaders();
        $token = str_replace('Bearer ', '', $headers['Authorization']);
        
        $this->sessaoUsuario->logout($token);
        
        echo json_encode(['success' => true, 'message' => 'Logout realizado com sucesso']);
    }
}
?>