<?php
require_once __DIR__ . '/../models/Instituicao.php';
require_once __DIR__ . '/../models/Documento.php';
require_once __DIR__ . '/../models/LogSistema.php';

class InstituicaoController {
    private $instituicao;
    private $documento;
    private $logSistema;
    private $userId;
    
    public function __construct($db, $userId) {
        $this->instituicao = new Instituicao($db);
        $this->documento = new Documento($db);
        $this->logSistema = new LogSistema($db);
        $this->userId = $userId;
    }
    
    public function getAll() {
        $instituicoes = $this->instituicao->findAll();
        echo json_encode($instituicoes);
    }
    
    public function getById($id) {
        $instituicao = $this->instituicao->findById($id);
        if($instituicao) {
            $documentos = $this->documento->findByInstituicao($id);
            $instituicao['documentos'] = $documentos;
            echo json_encode($instituicao);
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Instituição não encontrada']);
        }
    }
    
    public function create() {
        $data = json_decode(file_get_contents("php://input"));
        
        $this->instituicao->razao_social = $data->razao_social ?? '';
        $this->instituicao->nome_fantasia = $data->nome_fantasia ?? null;
        $this->instituicao->cnpj = $data->cnpj ?? '';
        $this->instituicao->endereco = $data->endereco ?? null;
        $this->instituicao->cidade = $data->cidade ?? null;
        $this->instituicao->estado = $data->estado ?? null;
        $this->instituicao->cep = $data->cep ?? null;
        $this->instituicao->telefone_principal = $data->telefone_principal ?? null;
        $this->instituicao->email = $data->email ?? null;
        $this->instituicao->site = $data->site ?? null;
        $this->instituicao->descricao = $data->descricao ?? null;
        $this->instituicao->data_fundacao = $data->data_fundacao ?? null;
        
        $id = $this->instituicao->create();
        
        if($id) {
            $this->logSistema->create($this->userId, 'CREATE', 'instituicao', "Criada instituição: {$this->instituicao->razao_social}");
            echo json_encode(['success' => true, 'id' => $id, 'message' => 'Instituição criada com sucesso']);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Erro ao criar instituição']);
        }
    }
    
    public function update($id) {
        $data = json_decode(file_get_contents("php://input"));
        
        $this->instituicao->id = $id;
        $this->instituicao->razao_social = $data->razao_social ?? '';
        $this->instituicao->nome_fantasia = $data->nome_fantasia ?? null;
        $this->instituicao->cnpj = $data->cnpj ?? '';
        $this->instituicao->endereco = $data->endereco ?? null;
        $this->instituicao->cidade = $data->cidade ?? null;
        $this->instituicao->estado = $data->estado ?? null;
        $this->instituicao->cep = $data->cep ?? null;
        $this->instituicao->telefone_principal = $data->telefone_principal ?? null;
        $this->instituicao->email = $data->email ?? null;
        $this->instituicao->site = $data->site ?? null;
        $this->instituicao->descricao = $data->descricao ?? null;
        $this->instituicao->data_fundacao = $data->data_fundacao ?? null;
        
        if($this->instituicao->update()) {
            $this->logSistema->create($this->userId, 'UPDATE', 'instituicao', "Atualizada instituição ID: {$id}");
            echo json_encode(['success' => true, 'message' => 'Instituição atualizada com sucesso']);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Erro ao atualizar instituição']);
        }
    }
    
    public function delete($id) {
        if($this->instituicao->delete($id)) {
            $this->logSistema->create($this->userId, 'DELETE', 'instituicao', "Excluída instituição ID: {$id}");
            echo json_encode(['success' => true, 'message' => 'Instituição excluída com sucesso']);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Erro ao excluir instituição']);
        }
    }
}
?>