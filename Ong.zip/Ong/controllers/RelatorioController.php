<?php
class RelatorioController {
    private $conn;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    public function getRelatorioGeral() {
        $query = "SELECT * FROM vw_relatorio_instituicao";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll();
        echo json_encode($result);
    }
    
    public function getRelatorioFinanceiro() {
        $query = "CALL sp_relatorio_parcerias()";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll();
        echo json_encode($result);
    }
    
    public function getDocumentosVencidos() {
        $query = "SELECT * FROM vw_documentos_vencidos";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll();
        echo json_encode($result);
    }
}
?>